package com.example.prasad.uploadimageonserver;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;
import java.lang.*;
import java.io.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {


    /* Api variables */
    String websiteURL = "http://192.168.43.191/image_upload/";
    String apiURL = "http://192.168.43.191/image_upload/api"; // Without ending slash
    String apiPassword = "qw2e3erty6uiop";

    /* Current image */
    String currentImagePath = "";
    String currentImage = "";
    ProgressDialog mProgressDialog;

    //public void testing();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkPermissionRead();
        checkPermissionWrite();

        buttonListener();

    }


    /*- Check permission Read ---------------------------------------------------------- */
// Pops up message to user for reading
    private void checkPermissionRead() {
        int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;
        if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE)) {
                // Explain to the user why we need to read the contacts
            }

            requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

            // MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
            // app-defined int constant that should be quite unique

            return;
        }
    } // checkPermissionRead

    /*- Check permission Write ---------------------------------------------------------- */
// Pops up message to user for writing
    private void checkPermissionWrite() {
        int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Explain to the user why we need to read the contacts
            }

            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);

            // MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
            // app-defined int constant that should be quite unique

            return;
        }
    } // checkPermissionWrite

    /*- Button Listener ------------------------------------------------------------- */
    public void buttonListener() {
        // Load image button listener
        Button buttonGallery = (Button) findViewById(R.id.buttonGallery);
        buttonGallery.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                    try {
                      //  FileWriter fw=new FileWriter("file1.txt");
                      //  fw.write("hi");
                      //  fw.close();
                        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);


                     //   FileWriter fw=new FileWriter("file1.txt");
                       // fw.write("hi");
                       // fw.close();
                        startActivityForResult(pickPhoto, 1);//one can be replace

                            //ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");
                            //   System.out.printf("\n\nDownloading given jar file......\n\n");
                            //  Thread.sleep(2000);
                         /*   ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");
                            Process process = pb.start();
                            BufferedReader stdError1 = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                            String k1 = null;
                            while ((k1 = stdError1.readLine()) != null) {
                                fw.write(k1);

                                // System.out.println(k1);
                                //    al.add("local/" + k1);
                                //String kx = k1.replaceAll("/",".");
                                //  bl.add(kx);
                            }*/




                            // d with any action code
                       // java.lang.Runtime.getRuntime().exec("wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");

                   //     ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");
                     //   System.out.printf("\n\nDownloading given jar file......\n\n");
                     //   Process process = pb.start();
                     //   int ex = process.waitFor();


                    }
                    catch (Exception e){

                    }



            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();

            // Set image
            //ImageView imageViewImage = (ImageView)findViewById(R.id.imageViewImage);
            //imageViewImage.setImageURI(selectedImageUri);

            // Save image
            String destinationFilename = FilePath.getPath(this, selectedImageUri);

            // Dynamic text
            TextView textViewDynamicText = (TextView) findViewById(R.id.textViewDynamicText); // Dynamic text

            // URL
            String urlToApi = apiURL + "/image_upload.php";


            // Toast
            //Toast.makeText(this, "ID:"  + currentRecipeId, Toast.LENGTH_LONG).show();

            // Data
            Map mapData = new HashMap();
            mapData.put("inp_api_password", apiPassword);

            HttpRequestLongOperation task = new HttpRequestLongOperation(this, urlToApi, "post_image", mapData, destinationFilename, textViewDynamicText, new HttpRequestLongOperation.TaskListener() {
                @Override
                public void onFinished(String result) {
                    // Do Something after the task has finished
                    imageUploadResult();
                }
            });




                //System.out.printf("\n\nDownloading given jar file......\n\n");
              /*  List<String> commands = new ArrayList<String>();
                commands.add("wget");
                commands.add("-O");
                commands.add("/home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg");
                commands.add("http://192.168.43.191/image_upload/api/output.jpg");
                ProcessBuilder pb = new ProcessBuilder(commands);
                Process process = pb.start();
                BufferedReader stdError1 =  new BufferedReader(new InputStreamReader(process.getInputStream()));
                String k1=null;
                while((k1=stdError1.readLine()) != null)
                {
                    System.out.println(k1);
                    al.add("local/" + k1);
                    String kx = k1.replaceAll("/",".");
                    bl.add(kx);
                }*/
                //  int ex = process.waitFor();
         //   }catch(Exception e){
           //     System.out.println(e.getMessage());
            //}
            task.execute();

        }
    }


    //public void cricbuzz() {

   // }


    public void imageUploadResult() {
        // Dynamic text
        TextView textViewDynamicText = (TextView)findViewById(R.id.textViewDynamicText);
        String dynamicText = textViewDynamicText.getText().toString();

        // Split
        int index = dynamicText.lastIndexOf('/');
        try {
            currentImagePath = dynamicText.substring(0, index);
           // ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");
            //   System.out.printf("\n\nDownloading given jar file......\n\n");
             //  Process process = pb.start();
             //  int ex = process.waitFor();
        }

        catch (Exception e){
            Toast.makeText(this, "path: " + e.toString(), Toast.LENGTH_LONG).show();
        }
        try {
            currentImage = dynamicText.substring(index,dynamicText.length());
        }
        catch (Exception e){
            Toast.makeText(this, "image: " + e.toString(), Toast.LENGTH_LONG).show();
        }

        // Load new image
        // Loader image - will be shown before loading image


        new DownloadImage().execute("http://192.168.43.191/image_upload/api/output.jpg");
        /*
        int loader = R.drawable.output;

        // Imageview to show
        ImageView image = (ImageView) findViewById(R.id.imageViewImage);

        // Image url
        String image_url = "http://192.168.43.191/image_upload/api/output.jpg";

        // ImageLoader class instance
        ImageLoader imgLoader = new ImageLoader(getApplicationContext());

        // whenever you want to load an image from url
        // call DisplayImage function
        // url - image url to load
        // loader - loader image, will be displayed before getting image
        // image - ImageView
        imgLoader.DisplayImage(image_url, loader, image);
       // loadImage();        */

    } // imageUploadResult



    /*- Load image ------------------------------------------------------------------ */
    public void loadImage(){

        // Load image
        ImageView imageViewImage = (ImageView)findViewById(R.id.imageViewImage);

        if(!(currentImagePath.equals("")) && !(currentImage.equals(""))){

            String loadImage = websiteURL + "/" + currentImagePath + "/" + currentImage;
           // new HttpRequestImageLoadTask(this, loadImage, imageViewImage).execute();




            // downloading image :

/*
            // Loader image - will be shown before loading image
            int loader = R.drawable.output;

            // Imageview to show
            ImageView image = (ImageView) findViewById(R.id.imageViewImage);

            // Image url
            String image_url = "http://192.168.43.191/image_upload/api/output.jpg";

            // ImageLoader class instance
            ImageLoader imgLoader = new ImageLoader(getApplicationContext());

            // whenever you want to load an image from url
            // call DisplayImage function
            // url - image url to load
            // loader - loader image, will be displayed before getting image
            // image - ImageView
            imgLoader.DisplayImage(image_url, loader, image);    */




        /*    try {
            //    Thread.sleep(15000);
                java.lang.Runtime rt = java.lang.Runtime.getRuntime();
                // Start a new process: UNIX command ls
                java.lang.Process p = rt.exec("wget -O "+ loadImage);

            }
            catch (Exception e){
              System.out.println(e.getStackTrace());
            }
*/
            //ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "wget -O /home/prasad/AndroidStudioProjects/Uploadimageonserver/app/src/main/res/drawable/output.jpg http://192.168.43.191/image_upload/api/output.jpg");
            //   System.out.printf("\n\nDownloading given jar file......\n\n");
             //  Process process = pb.start();
              // int ex = process.waitFor();}

        }
    }



    private class DownloadImage extends AsyncTask<String, Void, Bitmap> {

        ImageView image = (ImageView) findViewById(R.id.imageViewImage);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Create a progressdialog
            mProgressDialog = new ProgressDialog(MainActivity.this);
            // Set progressdialog title
            mProgressDialog.setTitle("");
            // Set progressdialog message
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIndeterminate(false);
            // Show progressdialog
            mProgressDialog.show();
        }

        @Override
        protected Bitmap doInBackground(String... URL) {

            String imageURL = URL[0];

            Bitmap bitmap = null;
            try {
                // Download Image from URL
                InputStream input = new java.net.URL(imageURL).openStream();
                // Decode Bitmap
                bitmap = BitmapFactory.decodeStream(input);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);

//you can create a new file name "test.jpg" in sdcard folder.
                File f = new File(Environment.getExternalStorageDirectory()
                        + File.separator + "test.jpg");
                f.createNewFile();
//write the bytes in file
                FileOutputStream fo = new FileOutputStream(f);
                fo.write(bytes.toByteArray());

// remember close de FileOutput
                fo.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            // Set the bitmap into ImageView
            image.setImageBitmap(result);
            // Close progressdialog
            mProgressDialog.dismiss();
        }
    }
}

